import { Hero } from "@/components/hero"
import { AboutBiodiesel } from "@/components/about-biodiesel"
import { ProjectObjectives } from "@/components/project-objectives"
import { Methodology } from "@/components/methodology"
import { EnvironmentalImpact } from "@/components/environmental-impact"
import { ExpectedResults } from "@/components/expected-results"
import { ProjectVideo } from "@/components/project-video"
import { References } from "@/components/references"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <Hero />
      <AboutBiodiesel />
      <ProjectObjectives />
      <Methodology />
      <EnvironmentalImpact />
      <ExpectedResults />
      <ProjectVideo />
      <References />
      <Footer />
    </main>
  )
}
