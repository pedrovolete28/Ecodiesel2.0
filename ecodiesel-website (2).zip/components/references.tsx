import { BookOpen, ExternalLink } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function References() {
  const references = [
    {
      author: "AGÊNCIA NACIONAL DO PETRÓLEO, GÁS NATURAL E BIOCOMBUSTÍVEIS (ANP)",
      title: "Biodiesel – Informações Técnicas",
      location: "[S. l.]",
      year: "[2025?]",
      url: "https://www.gov.br/anp/pt-br",
      access: "2 jul. 2025",
    },
    {
      author: "BRASIL. Ministério do Meio Ambiente",
      title: "Biodiesel: Energia que vem do óleo vegetal",
      location: "[S. l.]: Ministério do Meio Ambiente",
      year: "[2025]",
      url: null,
      access: null,
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <BookOpen className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Referências</h2>
            <p className="text-lg text-gray-600">Fontes utilizadas na pesquisa do projeto</p>
          </div>

          <Card className="border-green-200 shadow-xl">
            <CardHeader>
              <CardTitle className="text-center text-green-700">Bibliografia</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {references.map((ref, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg border-l-4 border-green-500">
                  <div className="space-y-2">
                    <p className="text-gray-800 leading-relaxed">
                      <strong>{ref.author}.</strong> <em>{ref.title}</em>. {ref.location}, {ref.year}.
                      {ref.url && (
                        <>
                          {" "}
                          Disponível em:{" "}
                          <a
                            href={ref.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-green-600 hover:text-green-700 underline inline-flex items-center gap-1"
                          >
                            {ref.url}
                            <ExternalLink className="h-3 w-3" />
                          </a>
                        </>
                      )}
                      {ref.access && <>. Acesso em: {ref.access}</>}.
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500">Referências formatadas segundo as normas da ABNT</p>
          </div>
        </div>
      </div>
    </section>
  )
}
