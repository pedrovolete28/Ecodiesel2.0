import { Recycle, Globe, Megaphone, FlaskConical, Users } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function ProjectObjectives() {
  const objectives = [
    {
      icon: Recycle,
      title: "Reaproveitar óleo de cozinha usado",
      description: "Evitando o desperdício e dando nova vida ao óleo usado",
    },
    {
      icon: Globe,
      title: "Reduzir a contaminação",
      description: "Diminuir a poluição do solo e da água causada pelo descarte inadequado",
    },
    {
      icon: Megaphone,
      title: "Promover educação ambiental",
      description: "Conscientizar sobre o uso responsável de recursos naturais",
    },
    {
      icon: FlaskConical,
      title: "Incentivar pesquisa e inovação",
      description: "Estimular o desenvolvimento de fontes de energia renovável",
    },
    {
      icon: Users,
      title: "Engajamento comunitário",
      description: "Promover a responsabilidade coletiva e participação social",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-green-50 to-emerald-50">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">Objetivos do Projeto</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {objectives.map((objective, index) => (
              <Card
                key={index}
                className="border-green-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <CardContent className="p-6">
                  <objective.icon className="h-12 w-12 text-green-600 mb-4" />
                  <h3 className="text-lg font-semibold mb-3 text-gray-800">{objective.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{objective.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
