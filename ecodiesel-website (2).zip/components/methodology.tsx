import { MapPin, Filter, FlaskConical, CheckCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function Methodology() {
  const steps = [
    {
      icon: MapPin,
      title: "Coleta",
      description: "Recolhimento de óleo em pontos parceiros e residências",
    },
    {
      icon: Filter,
      title: "Filtragem",
      description: "Remoção de impurezas e água do óleo coletado",
    },
    {
      icon: FlaskConical,
      title: "Transesterificação",
      description: "Reação química que transforma óleo em biodiesel e glicerina",
    },
    {
      icon: CheckCircle,
      title: "Testes de qualidade",
      description: "Verificação da viscosidade, queima e rendimento",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">Metodologia</h2>

          <div className="mb-12">
            <p className="text-lg text-gray-700 text-center max-w-4xl mx-auto leading-relaxed">
              O projeto envolve a coleta de óleo usado em restaurantes e lares, a filtragem do óleo e sua transformação
              em biodiesel por meio da reação de transesterificação. O processo é realizado em laboratório e o biodiesel
              resultante é testado quanto à sua eficiência, comparável ao diesel convencional.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, index) => (
              <Card key={index} className="border-green-200 hover:shadow-lg transition-shadow relative">
                <CardHeader className="text-center pb-4">
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-green-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold text-sm">
                    {index + 1}
                  </div>
                  <step.icon className="h-12 w-12 text-green-600 mx-auto mb-2 mt-4" />
                  <CardTitle className="text-lg text-gray-800">{step.title}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-600 text-center text-sm leading-relaxed">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
