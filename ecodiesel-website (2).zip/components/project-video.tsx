import { Play, ExternalLink } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function ProjectVideo() {
  // Substitua este link pelo link real do seu vídeo
  const videoUrl = "https://youtu.be/abPTWIl2tDc?feature=shared"

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Play className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Vídeo do Projeto</h2>
            <p className="text-lg text-gray-600">Veja nosso projeto na prática</p>
          </div>

          <Card className="border-blue-200 shadow-xl">
            <CardHeader>
              <CardTitle className="text-center text-blue-700">Demonstração Prática</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="mb-6">
                <div className="bg-gradient-to-r from-blue-100 to-indigo-100 rounded-lg p-8 mb-6">
                  <Play className="h-20 w-20 text-blue-600 mx-auto mb-4" />
                  <p className="text-gray-700 text-lg mb-4">
                    Assista ao vídeo da demonstração prática do nosso projeto de produção de biodiesel
                  </p>
                  <p className="text-gray-600">
                    Veja como transformamos óleo de cozinha usado em biodiesel através do processo de transesterificação
                  </p>
                </div>
              </div>

              <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3">
                <a href={videoUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2">
                  <Play className="h-5 w-5" />
                  Assistir Vídeo
                  <ExternalLink className="h-4 w-4" />
                </a>
              </Button>

              <p className="text-sm text-gray-500 mt-4">O vídeo será aberto em uma nova aba</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
