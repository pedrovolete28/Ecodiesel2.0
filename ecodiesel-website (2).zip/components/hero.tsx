"use client"

import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-green-600 via-green-700 to-emerald-800 text-white">
      <div className="absolute inset-0 bg-black/20" />
      <div className="relative container mx-auto px-4 py-24 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center mb-8">
            <img src="/images/biodiesel-logo.png" alt="Biodiesel Logo" className="h-32 w-auto" />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white">Ecodiesel</h1>

          <p className="text-xl md:text-2xl mb-4 text-green-100">Uso de Óleo para Biodiesel</p>

          <p className="text-lg mb-8 text-green-200 max-w-2xl mx-auto">
            Realizado por Estudantes do Sagrada Família - FT, DS e FDA
          </p>

          <Button
            size="lg"
            className="bg-white text-green-700 hover:bg-green-50 font-semibold px-8 py-3"
            onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}
          >
            Conheça o Projeto
          </Button>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-green-50 to-transparent" />
    </section>
  )
}
