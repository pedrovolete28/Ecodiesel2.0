import { CheckCircle } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function EnvironmentalImpact() {
  const impacts = [
    "Reduzir o desperdício de óleo de cozinha",
    "Minimizar a poluição da água e do solo",
    "Diminuir a emissão de gases poluentes",
    "Estimular o uso de fontes energéticas sustentáveis",
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-emerald-50 to-green-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">Impacto Ambiental</h2>

          <Card className="border-green-200 shadow-xl">
            <CardContent className="p-8">
              <p className="text-lg text-gray-700 mb-8 text-center">
                O uso de biodiesel a partir de óleo usado ajuda a:
              </p>

              <div className="grid md:grid-cols-2 gap-6">
                {impacts.map((impact, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
                    <p className="text-gray-700 leading-relaxed">{impact}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
