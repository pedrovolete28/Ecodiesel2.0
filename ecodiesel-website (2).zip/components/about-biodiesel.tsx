import { Fuel, Leaf, Globe, Factory } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function AboutBiodiesel() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">O que é Biodiesel?</h2>

          <div className="grid md:grid-cols-2 gap-8 items-center mb-12">
            <div>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                O biodiesel é um biocombustível produzido a partir de fontes renováveis, como óleos vegetais (soja,
                milho, canola) ou gorduras animais. Ele pode substituir total ou parcialmente o diesel derivado do
                petróleo em motores a combustão, sendo uma alternativa mais ecológica e menos poluente.
              </p>

              <p className="text-lg text-gray-700 leading-relaxed">
                Além de reduzir a emissão de gases do efeito estufa como CO₂, o biodiesel também contribui para a
                independência energética, valorizando recursos nacionais e regionais.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card className="border-green-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <Fuel className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold text-gray-800">Biocombustível</h3>
                </CardContent>
              </Card>

              <Card className="border-green-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <Leaf className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold text-gray-800">Renovável</h3>
                </CardContent>
              </Card>

              <Card className="border-green-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <Globe className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold text-gray-800">Ecológico</h3>
                </CardContent>
              </Card>

              <Card className="border-green-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <Factory className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="font-semibold text-gray-800">Nacional</h3>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
