import { Battery, Home, BookOpen, Globe } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function ExpectedResults() {
  const results = [
    {
      icon: Battery,
      title: "Produção mensal de biodiesel",
      description: "Suficiente para testes em laboratório",
    },
    {
      icon: Home,
      title: "Engajamento de comunidades locais",
      description: "No descarte correto de óleo",
    },
    {
      icon: BookOpen,
      title: "Realização de oficinas educativas",
      description: "Sobre energia limpa",
    },
    {
      icon: Globe,
      title: "Parcerias com ONGs e escolas",
      description: "Para ampliar o alcance do projeto",
    },
  ]

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">Resultados Esperados</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {results.map((result, index) => (
              <Card
                key={index}
                className="border-green-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <CardContent className="p-6 text-center">
                  <result.icon className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-3 text-gray-800">{result.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{result.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
