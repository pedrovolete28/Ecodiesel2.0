export function Footer() {
  const students = ["Gabriel T.", "Isadora F.", "Laura B.", "Marya S.", "Pedro V.", "Vitor S."]

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center items-center mb-6">
            <img src="/images/biodiesel-logo.png" alt="Biodiesel Logo" className="h-16 w-auto" />
          </div>

          <p className="text-gray-300 mb-6">© 2025. Projeto desenvolvido pelos estudantes:</p>

          <div className="flex flex-wrap justify-center gap-4 mb-6">
            {students.map((student, index) => (
              <span key={index} className="text-green-400 font-medium">
                {student}
              </span>
            ))}
          </div>

          <p className="text-gray-400 text-sm">Todos os direitos reservados.</p>

          <div className="mt-8 pt-8 border-t border-gray-700">
            <p className="text-gray-400 text-sm">Sagrada Família - FT, DS e FDA</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
